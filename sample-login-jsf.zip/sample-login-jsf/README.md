1. Setup Prerequisites
Before running the application, ensure you have the following tools installed:

JDK 11 or later
Verify installation:

bash
Copy code
java -version
Apache Maven
Verify installation:

bash
Copy code
mvn -version
MySQL Database
Ensure MySQL server is running and accessible. Create a database for the project as shown below.

An IDE (e.g., IntelliJ IDEA, Eclipse)
Use an IDE for easier project setup and debugging.

2. Clone the Project
If the project is hosted on GitHub:

bash
Copy code
git clone <repository-url>
cd jsflogindemo
If not, copy the folder structure and code provided.

3. Configure the Database
Start the MySQL server and create the database:

sql
Copy code
CREATE DATABASE jsf_demo;

USE jsf_demo;

CREATE TABLE user (
    userid VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL
);

INSERT INTO user (userid, password) VALUES ('testuser', 'password123');
Update application.properties with your database credentials:

properties
Copy code
spring.datasource.url=jdbc:mysql://localhost:3306/jsf_demo
spring.datasource.username=your_mysql_username
spring.datasource.password=your_mysql_password
4. Build and Run the Application
Open the project in your IDE (e.g., IntelliJ IDEA or Eclipse).

Build the project to ensure all dependencies are downloaded:

bash
Copy code
mvn clean install
Run the application:

bash
Copy code
mvn spring-boot:run
By default, the application runs on http://localhost:8080.

5. Test the Application
Frontend (JSF Login Page)
Open a browser and navigate to:

bash
Copy code
http://localhost:8080/login.xhtml
Enter the credentials:

User ID: testuser
Password: password123
Click the Submit button:

If the login is successful, the user will be redirected to welcome.xhtml.
If the login fails, an error message ("Invalid credentials") will be displayed.
Backend (REST API)
Use Postman, curl, or any REST client to test the API.

Make a POST request to:

bash
Copy code
http://localhost:8080/api/login
Use the following JSON body:

json
Copy code
{
    "userid": "testuser",
    "password": "password123"
}
Expected Responses:

200 OK: Login successful.
401 Unauthorized: Invalid credentials.
Example curl command:

bash
Copy code
curl -X POST http://localhost:8080/api/login \
     -H "Content-Type: application/json" \
     -d '{"userid":"testuser", "password":"password123"}'
6. Debugging Tips
Check application logs:
If something fails, review logs in the terminal/IDE console.

Verify database connection:
Ensure the database credentials in application.properties are correct.
Test the connection using a MySQL client.

Ensure dependencies are installed:
If Maven fails to download dependencies, clear the .m2 folder and rebuild:

bash
Copy code
rm -rf ~/.m2/repository
mvn clean install