package com.example.jsflogindemo.service;

import com.example.jsflogindemo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    @Autowired
    private UserRepository userRepository;

    public boolean authenticate(String userid, String password) {
        return userRepository.findByUseridAndPassword(userid, password).isPresent();
    }
}
