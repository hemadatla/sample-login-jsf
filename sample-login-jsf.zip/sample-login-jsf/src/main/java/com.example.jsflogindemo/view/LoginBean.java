package com.example.jsflogindemo;

import com.example.jsflogindemo.service.LoginService;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.SessionScoped;
import jakarta.faces.context.FacesContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@ManagedBean
@SessionScoped
@Component
public class LoginBean {
    private String userid;
    private String password;

    @Autowired
    private LoginService loginService;

    public String login() {
        if (loginService.authenticate(userid, password)) {
            return "welcome.xhtml";
        } else {
            FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage("Invalid credentials"));
            return null;
        }
    }

    // Getters and Setters
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
