package com.example.jsflogindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsflogindemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(JsflogindemoApplication.class, args);
    }
}
